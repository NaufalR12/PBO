/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package latihan_kuis;

/**
 *
 * @author LENOVO
 */
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class mainMenu extends JFrame {
    JButton Segitiga = new JButton("Segitiga");
    JButton Lingkaran = new JButton("Lingkaran");
    JButton Logout = new JButton("Logout");

    public mainMenu() {
        setTitle("Main Menu"); // Perbaiki judul menjadi "Main Menu"
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(350, 200); //(x,y)
        setLayout(null);

        add(Segitiga);
        add(Lingkaran);
        add(Logout);

        Segitiga.setBounds(10, 10, 30, 20); //(x,y,lebar,tinggi)
        Lingkaran.setBounds(210, 30, 30, 20);
        Logout.setBounds(50, 50, 100, 20);

        Segitiga.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new segitigaPage();
            }
        });

        Lingkaran.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new lingkaranPage();
            }
        });

        Logout.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

       
    }
}
