package Interface;

//interdace untuk G2D
public interface Bangun2D {
    public double hitungLuas();
    public double hitungKeliling();
}
