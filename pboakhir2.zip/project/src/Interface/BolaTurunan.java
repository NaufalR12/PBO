package Interface;

//interface untuk Turunan Bola
public interface BolaTurunan {
    public double hitungVolumeBT();
    public double hitungLuasPermukaanBT();
    
}
