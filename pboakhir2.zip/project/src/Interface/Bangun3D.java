package Interface;

//interface untuk G3D
public interface Bangun3D {
    public double hitungVolume();
    public double hitungLuasPermukaan();
    
}
