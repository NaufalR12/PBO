package TurunanBola;

import G3D.Bola;
import Interface.BolaTurunan;

public class Tembereng extends Bola implements BolaTurunan {

    private double tinggiTembereng;

    public Tembereng(double jariJari, double tinggiTembereng) {
        super(jariJari);
        this.tinggiTembereng = tinggiTembereng;
    }

    @Override
    public double hitungVolumeBT() {
        double volumeTembereng = (Math.PI * Math.pow(tinggiTembereng, 2) * (3 * r - tinggiTembereng)) / 3;
        return volumeTembereng;
    }

    @Override
    public double hitungLuasPermukaanBT() {
        double luasPermukaanTembereng = (2 * Math.PI * r * tinggiTembereng) + (2 * super.hitungLuas());
        return luasPermukaanTembereng;
    }
}