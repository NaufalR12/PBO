package TurunanBola;
import G3D.Bola;
import Interface.BolaTurunan;


public class Juring extends Bola implements BolaTurunan {

    private double panjangTaliBusur;

    public Juring(double r, double panjangTaliBusur) {
        super(r);
        this.panjangTaliBusur = panjangTaliBusur;
    }

    @Override
    public double hitungVolumeBT() {
        double volumeJuring = (Math.PI * Math.pow(r, 2) * panjangTaliBusur) / 3;
        return volumeJuring;
    }

    @Override
    public double hitungLuasPermukaanBT() {
        double luasPermukaanJuring = (2 * Math.PI * r * panjangTaliBusur) + (2 * super.hitungLuas());
        return luasPermukaanJuring;
    }
}