package TurunanBola;

import G3D.Bola;
import Interface.BolaTurunan;

public class CincinBola extends Bola implements BolaTurunan {

    private double rDalam;

    public CincinBola(double r, double rDalam) {
        super(r);
        this.rDalam = rDalam;
    }

    @Override
    public double hitungVolumeBT() {
        double volumeBolaLuar = super.hitungVolume();
        double volumeBolaDalam = (4 * Math.PI * Math.pow(rDalam, 3)) / 3;
        double volumeCincin = volumeBolaLuar - volumeBolaDalam;
        return volumeCincin;
    }

    @Override
    public double hitungLuasPermukaanBT() {
        double luasPermukaanBolaLuar = super.hitungLuasPermukaan();
        double luasPermukaanBolaDalam = 4 * Math.PI * Math.pow(rDalam, 2);
        double luasPermukaanCincin = luasPermukaanBolaLuar - luasPermukaanBolaDalam;
        return luasPermukaanCincin;
    }
}