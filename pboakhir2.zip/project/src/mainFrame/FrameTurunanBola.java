package mainFrame;

import G3D.*;
import TurunanBola.CincinBola;
import TurunanBola.Juring;
import TurunanBola.Tembereng;
import javax.swing.JOptionPane;

public class FrameTurunanBola extends javax.swing.JInternalFrame {

    public FrameTurunanBola() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        outputHasil = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        sisi1 = new javax.swing.JLabel();
        sisi2 = new javax.swing.JLabel();
        inputComboBoxJenis3 = new javax.swing.JComboBox<>();
        sisi3 = new javax.swing.JLabel();
        prosesButton = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        clearButton = new javax.swing.JButton();
        inputSatu = new javax.swing.JTextField();
        inputDua = new javax.swing.JTextField();
        inputTiga = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        sisi4 = new javax.swing.JLabel();
        inputEmpat = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        outputHasil2 = new javax.swing.JTextField();

        setClosable(true);
        setTitle("Turunan Bola");
        setPreferredSize(new java.awt.Dimension(650, 397));

        outputHasil.setEditable(false);

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel2.setText("Jenis ");

        sisi1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        sisi1.setText("-");

        sisi2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        sisi2.setText("-");

        inputComboBoxJenis3.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        inputComboBoxJenis3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pilih Jenis", "Cincin Bola", "Juring", "Tembereng" }));
        inputComboBoxJenis3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputComboBoxJenis3ActionPerformed(evt);
            }
        });

        sisi3.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        sisi3.setText("-");

        prosesButton.setText("Proses");
        prosesButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                prosesButtonActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel3.setText("Turunan Bola");

        clearButton.setText("Clear");
        clearButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearButtonActionPerformed(evt);
            }
        });

        inputSatu.setEnabled(false);
        inputSatu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputSatuActionPerformed(evt);
            }
        });

        inputDua.setEnabled(false);

        inputTiga.setEnabled(false);

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel4.setText("Volume");

        sisi4.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        sisi4.setText("-");

        inputEmpat.setEnabled(false);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel1.setText("Luas Permukaan");

        outputHasil2.setEditable(false);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(242, 242, 242)
                        .addComponent(jLabel3))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(70, 70, 70)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(inputSatu)
                            .addComponent(inputDua)
                            .addComponent(inputTiga)
                            .addComponent(inputEmpat)
                            .addComponent(inputComboBoxJenis3, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(sisi4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(sisi1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 110, Short.MAX_VALUE)
                                    .addComponent(sisi2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(sisi3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 22, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(outputHasil, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                                    .addComponent(outputHasil2))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 69, Short.MAX_VALUE)))
                        .addComponent(prosesButton, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(clearButton, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(19, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(inputComboBoxJenis3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(sisi1)
                    .addComponent(inputSatu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(sisi2)
                    .addComponent(inputDua, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(sisi3)
                    .addComponent(inputTiga, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(sisi4)
                    .addComponent(inputEmpat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 113, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(outputHasil2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(clearButton)
                    .addComponent(prosesButton)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(outputHasil, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12))
        );

        getAccessibleContext().setAccessibleName("3D Object");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void inputComboBoxJenis3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputComboBoxJenis3ActionPerformed
        try {
            switch (inputComboBoxJenis3.getSelectedIndex()) {
                case 0:
                    inputTiga.setEnabled(false);
                    inputSatu.setEnabled(false);
                    inputDua.setEnabled(false);
                    inputEmpat.setEnabled(false);
                    sisi1.setText("-");
                    sisi2.setText("-");
                    sisi3.setText("-");
                    sisi4.setText("-");
                    inputTiga.setText("");
                    inputSatu.setText("");
                    inputDua.setText("");
                    inputEmpat.setText("");
                    outputHasil.setText("");
                    outputHasil2.setText("");
                    break;
                case 1:// Untuk Cincin Bola --
                    inputTiga.setEnabled(false);
                    inputSatu.setEnabled(true);
                    inputDua.setEnabled(true);
                    inputEmpat.setEnabled(false);
                    sisi1.setText("Jari-jari Bola Luar");
                    sisi2.setText("Jari-jari Bola Dalam");
                    sisi3.setText("-");
                    sisi4.setText("-");
                    inputTiga.setText("");
                    inputSatu.setText("");
                    inputDua.setText("");
                    inputEmpat.setText("");
                    outputHasil.setText("");
                    outputHasil2.setText("");
                    break;
                case 2: //Juring --
                    inputTiga.setEnabled(false);
                    inputSatu.setEnabled(true);
                    inputDua.setEnabled(true);
                    inputEmpat.setEnabled(false);
                    sisi1.setText("Jari-jari Bola");
                    sisi2.setText("Panjang Tali Busur");
                    sisi3.setText("-");
                    sisi4.setText("-");
                    inputTiga.setText("");
                    inputSatu.setText("");
                    inputDua.setText("");
                    inputEmpat.setText("");
                    outputHasil.setText("");
                    outputHasil2.setText("");
                    break;
                case 3: // untuk tembereng --
                    inputTiga.setEnabled(false);
                    inputSatu.setEnabled(true);
                    inputDua.setEnabled(true);
                    inputEmpat.setEnabled(false);
                    sisi1.setText("Jari-jari Bola");
                    sisi2.setText("Tinggi Tembereng");
                    sisi3.setText("-");
                    sisi4.setText("-");
                    inputTiga.setText("");
                    inputSatu.setText("");
                    inputDua.setText("");
                    inputEmpat.setText("");
                    outputHasil.setText("");
                    outputHasil2.setText("");
                    break;
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Masukkan harus berupa angka.");
        }
    }//GEN-LAST:event_inputComboBoxJenis3ActionPerformed

    private void prosesButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_prosesButtonActionPerformed
        double nilaiSatu, nilaiDua, nilaiTiga, nilaiEmpat, hasil, hasil2;

        switch (inputComboBoxJenis3.getSelectedIndex()) {
            case 1:
                nilaiSatu = Double.parseDouble(inputSatu.getText());
                nilaiDua = Double.parseDouble(inputDua.getText());
                CincinBola cincinBola = new CincinBola(nilaiSatu, nilaiDua);
                hasil = cincinBola.hitungVolumeBT();
                hasil2 = cincinBola.hitungLuasPermukaanBT();
                outputHasil.setText("" + hasil);
                outputHasil2.setText("" + hasil2);
                break;
            case 2:
                nilaiSatu = Double.parseDouble(inputSatu.getText());
                nilaiDua = Double.parseDouble(inputDua.getText());
                Juring juring = new Juring(nilaiSatu, nilaiDua);
                hasil = juring.hitungVolumeBT();
                hasil2 = juring.hitungLuasPermukaanBT();
                outputHasil.setText("" + hasil);
                outputHasil2.setText("" + hasil2);
                break;
            case 3:
                nilaiSatu = Double.parseDouble(inputSatu.getText());
                nilaiDua = Double.parseDouble(inputDua.getText());
                Tembereng tembereng = new Tembereng(nilaiSatu, nilaiDua);
                hasil = tembereng.hitungVolumeBT();
                hasil2 = tembereng.hitungLuasPermukaanBT();
                outputHasil.setText("" + hasil);
                outputHasil2.setText("" + hasil2);
                break;
        }
    }//GEN-LAST:event_prosesButtonActionPerformed

    private void inputSatuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputSatuActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_inputSatuActionPerformed

    private void clearButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearButtonActionPerformed
        inputTiga.setText("");
        inputSatu.setText("");
        inputDua.setText("");
        outputHasil.setText("");
        outputHasil2.setText("");
        inputEmpat.setText("");
    }//GEN-LAST:event_clearButtonActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton clearButton;
    private javax.swing.JComboBox<String> inputComboBoxJenis3;
    private javax.swing.JTextField inputDua;
    private javax.swing.JTextField inputEmpat;
    private javax.swing.JTextField inputSatu;
    private javax.swing.JTextField inputTiga;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JTextField outputHasil;
    private javax.swing.JTextField outputHasil2;
    private javax.swing.JButton prosesButton;
    private javax.swing.JLabel sisi1;
    private javax.swing.JLabel sisi2;
    private javax.swing.JLabel sisi3;
    private javax.swing.JLabel sisi4;
    // End of variables declaration//GEN-END:variables
}
