package G3D;

import Interface.Bangun3D;

public class KerucutTerpancung extends Kerucut {
    private double tinggiTerpancung;

    public KerucutTerpancung(double r, double tinggiKerucut, double tinggiTerpancung) {
        super(r, tinggiKerucut);
        this.tinggiTerpancung = tinggiTerpancung;
    }

    @Override
    public double hitungVolume() {
        double volumeKerucut = super.hitungVolume();
        double volumeTerpancung = (Math.PI * Math.pow(r, 2) * tinggiTerpancung) / 3;
        double volumeTotal = volumeKerucut - volumeTerpancung;
        return volumeTotal;
    }

    @Override
    public double hitungLuasPermukaan() {
        double LPKerucut = super.hitungLuasPermukaan();
        double LPAlasTerpancung = Math.PI * Math.pow(r, 2);
        double LPKerucutTerpancung = Math.PI * r * Math.sqrt(Math.pow(r, 2) + Math.pow(tinggiTerpancung, 2));
        double luasTotal = LPKerucut + LPAlasTerpancung + LPKerucutTerpancung;
        return luasTotal;
    }
}