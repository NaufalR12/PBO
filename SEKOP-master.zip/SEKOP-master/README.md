# SEKOP
SEKOP atau Sistem Informasi Tiket Bioskop merupakan sebuat aplikasi untuk mengolah ada tiket bioskop berbasis Java
- Aplikasi ini merupakan sebuah projek dari mata kuliah Pemrograman Berbasis Objek (PBO) pada saat semester 2 dulu.
- Aplikasi ini merupakan aplikasi berbasis GUI dan berbasis objek pertama yang saya buat
- Aplikasi ini memiliki banyak kekurangan karena dulu membuatnya sedikit asal gara-gara kekurangan waktu
- Aplikasi ini hanya menjadi backup dan pembelajaran saja, jangan dianggap sebagai aplikasi yang legit
