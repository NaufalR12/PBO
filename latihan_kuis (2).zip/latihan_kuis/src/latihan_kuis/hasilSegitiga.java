/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package latihan_kuis;

/**
 *
 * @author LENOVO
 */
import javax.swing.*;

public class hasilSegitiga extends JFrame {
    JButton btnKembali = new JButton("Kembali");
    
    public hasilSegitiga(double alas, double tinggi) {
        setTitle("Hasil Segitiga");
        setDefaultCloseOperation(3);

        // Hitung luas segitiga
        double luas = 0.5 * alas * tinggi;

        // Tampilkan hasil
        
        JLabel hasilLuas = new JLabel("Luas Segitiga: " + luas);
        add(hasilLuas);
        add(btnKembali);
        hasilLuas.setBounds(30, 10, 120, 20);
        btnKembali.setBounds(60, 10, 120, 20);
        setSize(300, 200);
        setLocationRelativeTo(null); // Posisikan frame di tengah layar
        setVisible(true);
    }
}
