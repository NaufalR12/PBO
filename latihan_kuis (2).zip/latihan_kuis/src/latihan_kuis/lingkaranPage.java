/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package latihan_kuis;

/**
 *
 * @author LENOVO
 */
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class lingkaranPage extends JFrame {
    final JTextField fjari = new JTextField(10);

    JLabel ljari = new JLabel(" Alas : ");

    JButton btnHasil = new JButton("Hasil");

    public lingkaranPage() {
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setSize(350,200);
        setLayout(null);

        add(ljari);
        add(fjari);
        
        add(btnHasil);

        ljari.setBounds(10, 10, 120, 20);
        fjari.setBounds(130, 10, 150, 20);
        btnHasil.setBounds(40, 90, 100, 20);

        btnHasil.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                // Mendapatkan nilai alas dan tinggi
                double jari = Double.parseDouble(fjari.getText());
                
                // Mengirim nilai alas dan tinggi ke hasilSegitiga
                new hasilLingkaran(jari);
            }
        });
        setTitle("Lingkaran Page");
        setVisible(true);
    }
}

