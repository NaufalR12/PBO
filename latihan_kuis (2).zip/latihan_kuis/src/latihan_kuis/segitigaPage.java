/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package latihan_kuis;

/**
 *
 * @author LENOVO
 */
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class segitigaPage extends JFrame {
    final JTextField falas = new JTextField(10);
    final JTextField ftinggi = new JTextField(10);

    JLabel lalas = new JLabel(" Alas : ");
    JLabel ltinggi = new JLabel(" Tinggi : ");

    JButton btnHasil = new JButton("Hasil");

    public segitigaPage() {
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setSize(350,200);
        setLayout(null);

        add(lalas);
        add(falas);
        add(ltinggi);
        add(ftinggi);
        add(btnHasil);

        lalas.setBounds(10, 10, 120, 20);
        falas.setBounds(130, 10, 150, 20);
        ltinggi.setBounds(10, 40, 120, 20);
        ftinggi.setBounds(130, 40, 150, 20);
        btnHasil.setBounds(40, 90, 100, 20);

        btnHasil.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                // Mendapatkan nilai alas dan tinggi
                double alas = Double.parseDouble(falas.getText());
                double tinggi = Double.parseDouble(ftinggi.getText());
                
                // Mengirim nilai alas dan tinggi ke hasilSegitiga
                new hasilSegitiga(alas, tinggi);
            }
        });
        setTitle("Segitiga Page");
        setVisible(true);
    }
}
